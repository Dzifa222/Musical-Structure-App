package com.example.musicapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private MusicAdapter musicAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.musicListview);

        MusicObject song1 = new MusicObject("Song 1", "Meek Mill", "Championships");
        MusicObject song2 = new MusicObject("Song 2", "Rick Ross", "Teflon Don");
        MusicObject song3 = new MusicObject("Song 3", "Jay-Z", "I.Z.Z.O");
        MusicObject song4 = new MusicObject("Song 4", "Nipsey Hussle", "Double Up");
        MusicObject song5 = new MusicObject("Song 5", "Kanye West", "Stronger");

        final ArrayList<MusicObject> musicList = new ArrayList<>();

        //Adding Items to musicList
        musicList.add(song1);
        musicList.add(song2);
        musicList.add(song3);
        musicList.add(song4);
        musicList.add(song5);

        musicAdapter = new MusicAdapter(this, musicList);
        listView.setAdapter(musicAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    MusicObject word = musicList.get(position);

                    Intent playtrack = new Intent(MainActivity.this, NowPlayingActivity.class);
                    playtrack.putExtra("Title",word.getMusicName());
                    playtrack.putExtra("Album",word.getAlbum());
                    playtrack.putExtra("Artist",word.getArtist());
                    startActivity(playtrack);


            }
        });
    }
}
