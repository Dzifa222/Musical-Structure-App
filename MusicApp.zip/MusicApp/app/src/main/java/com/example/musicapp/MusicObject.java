package com.example.musicapp;

public class MusicObject {
    String musicName;
    String artist;
    String album;

    public MusicObject(String musicName, String artist, String album) {
        this.musicName = musicName;
        this.artist = artist;
        this.album = album;
    }

    public String getMusicName() {
        return musicName;
    }

    public String getArtist() {
        return artist;
    }

    public String getAlbum() {
        return album;
    }
}
