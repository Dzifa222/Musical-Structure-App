package com.example.musicapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class NowPlayingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_playing_layout);

        TextView songTitle = findViewById(R.id.songTitle_txt);
        TextView albumTitle = findViewById(R.id.albumTitle_txt);
        TextView artistName = findViewById(R.id.artistName_txt);
        ImageButton backButton = findViewById(R.id.back_btn);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NowPlayingActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Intent intent = getIntent();

        //Receives the data that was passed through the intent
        if (intent != null) {
            if (intent.hasExtra("Title")) {
                String receiveSongTitle = intent.getStringExtra("Title");
                String receiveAlbumTitle = intent.getStringExtra("Album");
                String receiveArtisteName = intent.getStringExtra("Artist");

                songTitle.setText(receiveSongTitle);
                albumTitle.setText(receiveAlbumTitle);
                artistName.setText(receiveArtisteName);
            }
        }
    }
}
